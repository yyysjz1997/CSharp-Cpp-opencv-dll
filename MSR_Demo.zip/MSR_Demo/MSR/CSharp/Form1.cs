﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;
using System.IO.Ports;
//using System.Threading.Tasks;
using System.Runtime.InteropServices;
//using INIFILE;
using System.IO;
using System.Text.RegularExpressions;
namespace CSharp
{
    public partial class Form1 : Form
    {
        public char ansback = new char { };
        //public char[] ansback_more = new char[100];

        public Form1()
        {
            InitializeComponent();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            // ansback =  CPPDLL.MSR_main_one();
            //Console.ReadLine();
            //textBox1.Text = ansback.ToString();
            // MessageBox.Show(CPPDLL.MSR_main_one().ToString());
            textBox1.Text = CPPDLL.MSR_main_one().ToString();
        }

        public void button2_Click(object sender, EventArgs e)
        {
            //ansback_more = CPPDLL.MSR_main();
            //textBox1.Text = ansback_more.ToString();
            textBox1.Text = CPPDLL.MSR_main().ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CPPDLL.show();
        }

    }
}
