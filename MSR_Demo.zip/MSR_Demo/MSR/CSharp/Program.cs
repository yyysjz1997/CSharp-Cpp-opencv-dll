﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CSharp
{
    class Program
    {
       // [DllImport("MSR.dll", CharSet = CharSet.Ansi)]
        //public static extern spot1(int i, Mat scr);//scr是传递过来打开的原图
       // public static extern char[][] MSR_main();

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            // CPPDLL.show();
            // char t[7][10] = CPPDLL.MSR_main();
            // Console.ReadLine();
            ///Console.ReadKey();
        }
    }
}
