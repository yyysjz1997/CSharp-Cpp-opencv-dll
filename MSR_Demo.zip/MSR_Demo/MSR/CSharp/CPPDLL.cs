﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace CSharp
{
    class CPPDLL
    {
        //[DllImport("MSR.dll", CharSet = CharSet.Ansi)]
        [DllImport("MSR.dll", EntryPoint = "MSR_main", CharSet = CharSet.Ansi, SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern byte MSR_main();
        [DllImport("MSR.dll", EntryPoint = "MSR_main_one", CharSet = CharSet.Ansi, SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern char MSR_main_one();
        [DllImport("MSR.dll", EntryPoint = "show", CharSet = CharSet.Ansi, SetLastError = true, CallingConvention = CallingConvention.StdCall)]
        public static extern void show();
        //public static extern void show();
        // public static char spot1(int i, Mat scr);//scr是传递过来打开的原图
    }
}
