//#pragma once
#ifndef EXPORT_H
#define EXPORT_H

#ifndef EXPORT_DLL
#define EXPORT_API    __declspec(dllexport)
#else
#define EXPORT_API    __declspec(dllexport)
#endif // !1

#endif
